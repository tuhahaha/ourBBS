
$(document).ready(function(){
    $("#myNav").affix({
        offset: { 
            top: 125 
      }
    });
});

function  delet()
{
	var parent=document.getElementById("mess2");
	var x=document.getElementById("mess2").getElementsByTagName("p");
	var child=x[0];
	parent.removeChild(child);
}

function add_head(){
	alert("add_head!!!!!!!\n");
	var x=document.getElementById("mymessage_head").value;
	var aNode=document.createElement("a");
	aNode.href="#";
	aNode.innerHTML=x;
	var divNode=document.getElementById("my_ul");
	var xx=document.createElement("li");
	xx.appendChild(aNode);
	divNode.appendChild(xx);
}

function save_art(){
	alert("save_art!!!!!!!\n");
	var hd=document.getElementById("mymessage_head").value;
	var bd=document.getElementById("mymessage_body").value;
	var a=document.getElementById("test");
	a.innerHTML=hd+","+bd;
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	alert("!!!\n");
	var f1 = fso.GetFile("c:\myjstest.txt");
	alert("File last modified: " + f1.DateLastModified);
}
function add_comment(){
			var name=document.getElementById("my_name").innerHTML;
			var node1=document.createElement("h4");
			node1.style.color="blue";
			var namee=document.createTextNode(name);
			node1.appendChild(namee);
		
			var d=new Date();	
			var month=d.getMonth();
			var month1=month+1;
			var nowtime=d.getFullYear()+"-"+month1+"-"+d.getDate()+"   "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();

			var node2=document.createElement("p");
			var time=document.createTextNode(nowtime);
			node2.appendChild(time);
			
			
			var comment=document.getElementById("my_comment").value;
			var node3=document.createElement("p");
			var commentbody=document.createTextNode(comment);
			node3.appendChild(commentbody);
			
			var node=document.createElement("div");
			node.className="comments";
			node.appendChild(node1);
			node.appendChild(node2);
			node.appendChild(node3);
			
			var element=document.getElementById("comments_area");
			element.appendChild(node);
			document.getElementById("comments_area").value ="";
}